/**
 * JANO - Controlador do Dashboard de Recursos Humanos
 * Regras: RF01, RF02, RF03, RF15, RN01, RN07
 */

document.addEventListener('DOMContentLoaded', async () => {
    // RBAC: Somente o perfil 'RH' pode acessar este painel
    window.JanoAuth.guardRoute(['RH']);

    // Renderiza componentes visuais comuns
    window.JanoComponents.renderNavbar('navbar-container');
    window.JanoComponents.renderFooter('footer-container');

    // Inicializa modais Bootstrap
    const modalCadastrarEl = document.getElementById('modal-novo-funcionario');
    const modalCadastrar = new bootstrap.Modal(modalCadastrarEl);

    const modalCredenciaisEl = document.getElementById('modal-credenciais-geradas');
    const modalCredenciais = new bootstrap.Modal(modalCredenciaisEl);

    // Carrega dados iniciais
    await carregarMetricas();
    await carregarEquipesSelect();
    await carregarFuncionarios();

    // Evento de submit do cadastro
    const formCad = document.getElementById('form-cadastrar-funcionario');
    formCad.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errorAlert = document.getElementById('modal-error-alert');
        errorAlert.classList.add('d-none');

        const btnSubmit = document.getElementById('btn-submit-cad');
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Cadastrando...';

        const dados = {
            nome: document.getElementById('cad-nome').value.trim(),
            cpf: document.getElementById('cad-cpf').value.trim(),
            cargo: document.getElementById('cad-cargo').value.trim(),
            telefone: document.getElementById('cad-telefone').value.trim(),
            email: document.getElementById('cad-email').value.trim(),
            perfil: document.getElementById('cad-perfil').value,
            id_equipe: document.getElementById('cad-equipe').value || null
        };

        try {
            const res = await window.JanoAPI.Funcionarios.cadastrar(dados);

            if (res.sucesso) {
                modalCadastrar.hide();
                formCad.reset();

                // Exibe modal com as credenciais geradas
                document.getElementById('cred-email').textContent = res.credenciaisTemporarias.email;
                document.getElementById('cred-senha').textContent = res.credenciaisTemporarias.senhaTemporaria;
                modalCredenciais.show();

                window.JanoComponents.showToast('Colaborador cadastrado e credenciais geradas!', 'sucesso');

                // Recarrega lista e métricas
                await carregarFuncionarios();
                await carregarMetricas();
            } else {
                errorAlert.textContent = res.mensagem || 'Erro ao cadastrar funcionário.';
                errorAlert.classList.remove('d-none');
            }
        } catch (error) {
            errorAlert.textContent = error.message || 'Erro na comunicação com o servidor.';
            errorAlert.classList.remove('d-none');
        } finally {
            btnSubmit.disabled = false;
            btnSubmit.innerHTML = 'Cadastrar e Gerar Credenciais';
        }
    });

    // Botão de copiar senha gerada
    document.getElementById('btn-copiar-senha').addEventListener('click', () => {
        const senha = document.getElementById('cred-senha').textContent;
        navigator.clipboard.writeText(senha).then(() => {
            window.JanoComponents.showToast('Senha temporária copiada para a área de transferência!', 'info');
        });
    });
});

async function carregarMetricas() {
    try {
        const res = await window.JanoAPI.Dashboard.getMetricasRH();
        if (res.sucesso && res.metricas) {
            const m = res.metricas;
            document.getElementById('metric-colaboradores').textContent = m.totalColaboradores;
            document.getElementById('metric-equipes').textContent = m.totalEquipes;
            document.getElementById('metric-primeiro-acesso').textContent = m.primeiroAcessoPendente;
            document.getElementById('metric-conclusao').textContent = `${m.taxaConclusaoGeral}%`;
        }
    } catch (err) {
        console.error('Erro ao buscar métricas do RH:', err);
    }
}

async function carregarEquipesSelect() {
    try {
        const res = await window.JanoAPI.Equipes.listar();
        const select = document.getElementById('cad-equipe');
        if (res.sucesso && res.equipes) {
            select.innerHTML = '<option value="">Nenhuma equipe no momento (Alocação posterior pelo Gestor)</option>';
            res.equipes.forEach(eq => {
                select.innerHTML += `<option value="${eq.id}">${eq.nome} (${eq.departamento})</option>`;
            });
        }
    } catch (err) {
        console.error('Erro ao carregar lista de equipes:', err);
    }
}

async function carregarFuncionarios() {
    const tbody = document.getElementById('tabela-funcionarios-body');
    const badgeTotal = document.getElementById('badge-total-tabela');

    try {
        const res = await window.JanoAPI.Funcionarios.listar();
        if (!res.sucesso || !res.funcionarios) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-danger">Falha ao carregar colaboradores.</td></tr>';
            return;
        }

        const lista = res.funcionarios;
        badgeTotal.textContent = `${lista.length} colaborador${lista.length === 1 ? '' : 'es'}`;

        if (lista.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">Nenhum funcionário cadastrado no momento.</td></tr>';
            return;
        }

        const perfilBadgeMap = {
            'RH': 'badge-rh',
            'Gestor': 'badge-gestor',
            'Funcionario': 'badge-funcionario'
        };

        const usuarioLogado = window.JanoAuth.getUser();

        tbody.innerHTML = lista.map(func => {
            const isMe = usuarioLogado && usuarioLogado.id === func.id;
            const statusAcessoBadge = func.primeiro_acesso
                ? `<span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>1º Acesso Pendente</span>`
                : `<span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Ativo / Liberado</span>`;

            return `
                <tr>
                    <td>
                        <div class="fw-bold">${func.nome} ${isMe ? '<span class="badge bg-secondary ms-1">Você</span>' : ''}</div>
                        <small class="text-muted"><i class="bi bi-card-text me-1"></i>${func.cpf}</small>
                    </td>
                    <td>
                        <div class="fw-semibold">${func.cargo}</div>
                        <small class="text-muted"><i class="bi bi-diagram-2 me-1"></i>${func.equipe_nome || 'Sem equipe'}</small>
                    </td>
                    <td>
                        <a href="mailto:${func.email}" class="text-decoration-none text-primary small">
                            ${func.email}
                        </a>
                        ${func.telefone ? `<br><small class="text-muted"><i class="bi bi-telephone me-1"></i>${func.telefone}</small>` : ''}
                    </td>
                    <td>
                        <span class="badge ${perfilBadgeMap[func.perfil] || 'badge-funcionario'}">
                            ${func.perfil}
                        </span>
                    </td>
                    <td>
                        ${statusAcessoBadge}
                    </td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div class="progress flex-grow-1" style="height: 6px;">
                                <div class="progress-bar bg-primary" role="progressbar" style="width: ${func.progresso_onboarding || 0}%"></div>
                            </div>
                            <span class="small fw-semibold text-muted">${func.progresso_onboarding || 0}%</span>
                        </div>
                        <small class="text-muted">${func.tarefas_concluidas || 0}/${func.total_tarefas || 0} tarefas</small>
                    </td>
                    <td class="text-center">
                        ${!isMe ? `
                            <button type="button" class="btn btn-outline-danger btn-sm" onclick="confirmarDesligamento(${func.id}, '${escapeHtml(func.nome)}')" title="Efetuar Desligamento (RN01, RN07, RF15)">
                                <i class="bi bi-person-x-fill me-1"></i> Desligar
                            </button>
                        ` : `
                            <span class="text-muted small">Conta Atual</span>
                        `}
                    </td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        tbody.innerHTML = `<tr><td colspan="7" class="text-center py-4 text-danger">Erro: ${error.message}</td></tr>`;
    }
}

window.confirmarDesligamento = async function(id, nome) {
    const confirmou = confirm(`CONFIRMAÇÃO DE DESLIGAMENTO (RN01/RN07/RF15):\n\nDeseja realmente desligar e excluir o cadastro de "${nome}"?\nEsta ação removerá o colaborador do sistema e das equipes associadas.`);
    if (!confirmou) return;

    try {
        const res = await window.JanoAPI.Funcionarios.excluir(id);
        if (res.sucesso) {
            window.JanoComponents.showToast(`Colaborador "${nome}" desligado com sucesso.`, 'aviso');
            await carregarFuncionarios();
            await carregarMetricas();
        } else {
            alert(res.mensagem || 'Falha ao excluir colaborador.');
        }
    } catch (error) {
        alert(error.message || 'Erro ao processar desligamento.');
    }
};

function escapeHtml(text) {
    return (text || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
}
