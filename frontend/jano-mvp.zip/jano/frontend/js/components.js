/**
 * JANO Components - Componentização em Vanilla JS
 * Renderiza Navbar corporativa dinâmica, Toasts e Elementos Compartilhados
 */

const JanoComponents = {
    renderNavbar(containerId = 'navbar-container') {
        const container = document.getElementById(containerId);
        if (!container) return;

        const user = window.JanoAuth ? window.JanoAuth.getUser() : null;
        if (!user) return;

        const perfilCores = {
            'RH': 'badge-rh',
            'Gestor': 'badge-gestor',
            'Funcionario': 'badge-funcionario'
        };

        const perfilLabels = {
            'RH': 'Recursos Humanos',
            'Gestor': 'Gestor de Equipe',
            'Funcionario': 'Novo Colaborador'
        };

        const html = `
            <nav class="navbar navbar-expand-lg navbar-jano">
                <div class="container-fluid">
                    <a class="navbar-brand navbar-brand-jano" href="${window.JanoAuth.getDashboardUrl(user.perfil)}">
                        <span>⚡ JANO</span>
                        <span class="brand-badge">Onboarding Corp</span>
                    </a>

                    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                        <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navMenu">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                            ${user.perfil === 'RH' ? `
                                <li class="nav-item">
                                    <a class="nav-link text-white fw-semibold" href="dashboard-rh.html">
                                        <i class="bi bi-people me-1"></i> Gestão de Pessoas
                                    </a>
                                </li>
                            ` : ''}

                            ${user.perfil === 'Gestor' ? `
                                <li class="nav-item">
                                    <a class="nav-link text-white fw-semibold" href="dashboard-gestor.html">
                                        <i class="bi bi-diagram-3 me-1"></i> Equipes & Tarefas
                                    </a>
                                </li>
                            ` : ''}

                            ${user.perfil === 'Funcionario' ? `
                                <li class="nav-item">
                                    <a class="nav-link text-white fw-semibold" href="dashboard-funcionario.html">
                                        <i class="bi bi-check2-circle me-1"></i> Minhas Tarefas
                                    </a>
                                </li>
                            ` : ''}
                        </ul>

                        <div class="d-flex align-items-center gap-3">
                            <div class="user-pill d-none d-sm-flex">
                                <span class="user-role ${perfilCores[user.perfil] || 'badge-funcionario'}">
                                    ${perfilLabels[user.perfil] || user.perfil}
                                </span>
                                <span class="fw-semibold small">${user.nome}</span>
                            </div>

                            <button id="btn-logout" class="btn btn-outline-light btn-sm px-3 rounded-pill" onclick="window.JanoAuth.logout()">
                                <i class="bi bi-box-arrow-right me-1"></i> Sair
                            </button>
                        </div>
                    </div>
                </div>
            </nav>
        `;

        container.innerHTML = html;
    },

    renderFooter(containerId = 'footer-container') {
        const container = document.getElementById(containerId);
        if (!container) return;

        const html = `
            <footer class="footer-jano text-center">
                <div class="container">
                    <p class="mb-1 text-muted">
                        <strong>JANO</strong> &copy; 2026 - Sistema de Automatização do Processo de Onboarding Corporativo
                    </p>
                    <small class="text-secondary">Trabalho de Conclusão de Curso - ETEC São Mateus | MTEC Desenvolvimento de Sistemas</small>
                </div>
            </footer>
        `;
        container.innerHTML = html;
    },

    showToast(mensagem, tipo = 'info') {
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            toastContainer.style.zIndex = '9999';
            document.body.appendChild(toastContainer);
        }

        const bgMap = {
            'sucesso': 'bg-success text-white',
            'erro': 'bg-danger text-white',
            'aviso': 'bg-warning text-dark',
            'info': 'bg-primary text-white'
        };

        const toastId = 'toast_' + Date.now();
        const toastEl = document.createElement('div');
        toastEl.id = toastId;
        toastEl.className = `toast align-items-center border-0 shadow ${bgMap[tipo] || bgMap.info}`;
        toastEl.setAttribute('role', 'alert');
        toastEl.setAttribute('aria-live', 'assertive');
        toastEl.setAttribute('aria-atomic', 'true');

        toastEl.innerHTML = `
            <div class="d-flex">
                <div class="toast-body fw-semibold">
                    ${mensagem}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;

        toastContainer.appendChild(toastEl);
        const bsToast = new bootstrap.Toast(toastEl, { delay: 4000 });
        bsToast.show();

        toastEl.addEventListener('hidden.bs.toast', () => {
            toastEl.remove();
        });
    }
};

window.JanoComponents = JanoComponents;
