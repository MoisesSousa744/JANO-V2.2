/**
 * JANO - Controlador do Portal de Onboarding do Colaborador
 * Regras: RF08, RF09, RN03, RN04
 */

let tarefasPendentesGlobais = [];

document.addEventListener('DOMContentLoaded', async () => {
    // Garante autenticação e direcionamento correto
    window.JanoAuth.guardRoute(['Funcionario', 'Gestor', 'RH']);

    window.JanoComponents.renderNavbar('navbar-container');
    window.JanoComponents.renderFooter('footer-container');

    const usuario = window.JanoAuth.getUser();
    if (usuario) {
        document.getElementById('user-welcome-nome').textContent = `Olá, ${usuario.nome}!`;
        document.getElementById('user-welcome-cargo').textContent = `Cargo: ${usuario.cargo || 'Colaborador'} | Onboarding Corporativo JANO`;
    }

    const modalEntregaEl = document.getElementById('modal-entregar-tarefa');
    const modalEntrega = new bootstrap.Modal(modalEntregaEl);

    // Carrega tarefas do funcionário
    await carregarMinhasTarefas();

    // Evento de submissão da entrega da tarefa
    const formEntrega = document.getElementById('form-entregar-tarefa');
    formEntrega.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errorAlert = document.getElementById('modal-entrega-error');
        errorAlert.classList.add('d-none');

        const idTarefa = document.getElementById('entrega-tarefa-id').value;
        const evidencia = document.getElementById('entrega-evidencia').value.trim();

        if (!evidencia) {
            errorAlert.textContent = 'Por favor, informe a descrição ou link de comprovação da tarefa.';
            errorAlert.classList.remove('d-none');
            return;
        }

        const btnSubmit = document.getElementById('btn-submit-entrega');
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Registrando entrega...';

        try {
            const res = await window.JanoAPI.Tarefas.concluir(idTarefa, evidencia);

            if (res.sucesso) {
                modalEntrega.hide();
                formEntrega.reset();
                window.JanoComponents.showToast('Parabéns! Tarefa entregue com sucesso.', 'sucesso');
                await carregarMinhasTarefas();
            } else {
                errorAlert.textContent = res.mensagem || 'Falha ao registrar entrega da tarefa.';
                errorAlert.classList.remove('d-none');
            }
        } catch (error) {
            errorAlert.textContent = error.message || 'Erro de comunicação ao entregar tarefa.';
            errorAlert.classList.remove('d-none');
        } finally {
            btnSubmit.disabled = false;
            btnSubmit.innerHTML = '<i class="bi bi-check-lg me-1"></i>Confirmar e Finalizar Tarefa';
        }
    });
});

async function carregarMinhasTarefas() {
    const containerPendentes = document.getElementById('container-tarefas-pendentes');
    const containerConcluidas = document.getElementById('container-tarefas-concluidas');

    try {
        const res = await window.JanoAPI.Tarefas.listar();

        if (!res.sucesso) {
            containerPendentes.innerHTML = '<div class="col-12 text-center text-danger">Falha ao carregar suas tarefas de integração.</div>';
            return;
        }

        const pendentes = res.pendentes || [];
        const concluidas = res.concluidas || [];
        tarefasPendentesGlobais = pendentes;

        const total = pendentes.length + concluidas.length;
        const percentual = total > 0 ? Math.round((concluidas.length / total) * 100) : 0;

        // Atualiza barra e badges de progresso
        document.getElementById('progresso-percentual').textContent = `${percentual}%`;
        document.getElementById('progresso-bar').style.width = `${percentual}%`;
        document.getElementById('progresso-detalhes').textContent = `${concluidas.length} de ${total} tarefa${total === 1 ? '' : 's'} concluída${concluidas.length === 1 ? '' : 's'}`;

        document.getElementById('badge-pendentes-count').textContent = `${pendentes.length} pendente${pendentes.length === 1 ? '' : 's'}`;
        document.getElementById('badge-concluidas-count').textContent = `${concluidas.length} concluída${concluidas.length === 1 ? '' : 's'}`;

        // Renderiza Tarefas Pendentes
        if (pendentes.length === 0) {
            containerPendentes.innerHTML = `
                <div class="col-12">
                    <div class="card card-jano p-4 text-center text-success bg-success-subtle border-success-subtle">
                        <i class="bi bi-patch-check-fill fs-2 mb-2"></i>
                        <h6 class="fw-bold mb-1">Excelente! Nenhuma tarefa pendente</h6>
                        <small>Você completou todas as atividades de onboarding atribuídas a você até o momento.</small>
                    </div>
                </div>
            `;
        } else {
            containerPendentes.innerHTML = pendentes.map(t => {
                const formatPrazo = t.prazo ? t.prazo.split('T')[0] : 'Sem prazo';
                return `
                    <div class="col-12 col-md-6 col-xl-4">
                        <div class="card task-card pending h-100 p-3 d-flex flex-column justify-content-between">
                            <div>
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Pendente</span>
                                    <small class="text-danger fw-semibold"><i class="bi bi-calendar-event me-1"></i>Prazo: ${formatPrazo}</small>
                                </div>
                                <h6 class="fw-bold text-dark mb-2">${t.titulo}</h6>
                                <p class="small text-secondary mb-3">${t.descricao || 'Sem descrição específica.'}</p>
                            </div>
                            <div class="pt-3 border-top d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    ${t.equipe_nome ? `<i class="bi bi-diagram-2 me-1"></i>${t.equipe_nome}` : '<i class="bi bi-person me-1"></i>Individual'}
                                </small>
                                <button type="button" class="btn btn-sm btn-jano-primary" onclick="abrirModalEntrega(${t.id})">
                                    <i class="bi bi-send-check me-1"></i>Entregar Tarefa
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Renderiza Tarefas Concluídas
        if (concluidas.length === 0) {
            containerConcluidas.innerHTML = `
                <div class="col-12">
                    <div class="card card-jano p-4 text-center text-muted">
                        <i class="bi bi-clipboard2-check fs-2 mb-2"></i>
                        <h6 class="fw-bold mb-1">Nenhuma entrega realizada ainda</h6>
                        <small>Quando você concluir uma tarefa e submeter a evidência, ela aparecerá aqui.</small>
                    </div>
                </div>
            `;
        } else {
            containerConcluidas.innerHTML = concluidas.map(t => {
                let evidenciaHtml = '';
                if (t.evidencia) {
                    const isUrl = t.evidencia.startsWith('http://') || t.evidencia.startsWith('https://');
                    evidenciaHtml = isUrl
                        ? `<a href="${t.evidencia}" target="_blank" class="btn btn-sm btn-outline-success py-0 px-2 mt-2"><i class="bi bi-link-45deg me-1"></i>Ver Evidência (Link)</a>`
                        : `<div class="p-2 bg-light rounded small text-secondary mt-2 border"><i class="bi bi-chat-quote me-1"></i><strong>Evidência:</strong> ${t.evidencia}</div>`;
                }

                return `
                    <div class="col-12 col-md-6 col-xl-4">
                        <div class="card task-card completed h-100 p-3">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge bg-success"><i class="bi bi-check-circle-fill me-1"></i>Concluída</span>
                                <small class="text-muted"><i class="bi bi-calendar-check me-1"></i>Finalizada</small>
                            </div>
                            <h6 class="fw-bold text-dark mb-1 text-decoration-line-through text-muted">${t.titulo}</h6>
                            <p class="small text-secondary mb-2">${t.descricao || ''}</p>
                            ${evidenciaHtml}
                        </div>
                    </div>
                `;
            }).join('');
        }
    } catch (err) {
        containerPendentes.innerHTML = `<div class="col-12 text-center text-danger">Erro: ${err.message}</div>`;
    }
}

window.abrirModalEntrega = function(idTarefa) {
    const tarefa = tarefasPendentesGlobais.find(t => t.id === idTarefa);
    if (!tarefa) return;

    document.getElementById('entrega-tarefa-id').value = tarefa.id;
    document.getElementById('entrega-tarefa-titulo').textContent = tarefa.titulo;
    document.getElementById('entrega-tarefa-descricao').textContent = tarefa.descricao || 'Sem orientações adicionais.';
    document.getElementById('entrega-evidencia').value = '';
    document.getElementById('modal-entrega-error').classList.add('d-none');

    const modal = bootstrap.Modal.getInstance(document.getElementById('modal-entregar-tarefa')) ||
                  new bootstrap.Modal(document.getElementById('modal-entregar-tarefa'));
    modal.show();
};
