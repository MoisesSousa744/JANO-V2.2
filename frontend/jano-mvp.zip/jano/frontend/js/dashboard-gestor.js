/**
 * JANO - Controlador do Dashboard do Gestor de Equipes
 * Regras: RF06, RF07, RF10, RF11, RF12, RF13, RN05, RN08
 */

let equipesGlobais = [];
let funcionariosGlobais = [];

document.addEventListener('DOMContentLoaded', async () => {
    // RBAC: Gestor ou RH podem acessar
    window.JanoAuth.guardRoute(['Gestor', 'RH']);

    window.JanoComponents.renderNavbar('navbar-container');
    window.JanoComponents.renderFooter('footer-container');

    // Modais Bootstrap
    const modalEquipeEl = document.getElementById('modal-nova-equipe');
    const modalEquipe = new bootstrap.Modal(modalEquipeEl);

    const modalTarefaEl = document.getElementById('modal-atribuir-tarefa');
    const modalTarefa = new bootstrap.Modal(modalTarefaEl);

    const modalVincularEl = document.getElementById('modal-vincular-membro');
    const modalVincular = new bootstrap.Modal(modalVincularEl);

    // Carregamento inicial
    await carregarMetricas();
    await carregarDadosCompletos();

    // Alternância do rádio Individual vs Equipe
    const radioIndividual = document.getElementById('tipoIndividual');
    const radioEquipe = document.getElementById('tipoEquipe');
    const boxFuncionario = document.getElementById('box-select-funcionario');
    const boxEquipe = document.getElementById('box-select-equipe');

    radioIndividual.addEventListener('change', () => {
        boxFuncionario.classList.remove('d-none');
        boxEquipe.classList.add('d-none');
    });

    radioEquipe.addEventListener('change', () => {
        boxFuncionario.classList.add('d-none');
        boxEquipe.classList.remove('d-none');
    });

    // Submissão: Criar Nova Equipe (RF10)
    const formEquipe = document.getElementById('form-criar-equipe');
    formEquipe.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errEl = document.getElementById('modal-equipe-error');
        errEl.classList.add('d-none');

        const dados = {
            nome: document.getElementById('eq-nome').value.trim(),
            departamento: document.getElementById('eq-departamento').value.trim()
        };

        try {
            const res = await window.JanoAPI.Equipes.criar(dados);
            if (res.sucesso) {
                modalEquipe.hide();
                formEquipe.reset();
                window.JanoComponents.showToast('Equipe criada com sucesso!', 'sucesso');
                await carregarDadosCompletos();
                await carregarMetricas();
            } else {
                errEl.textContent = res.mensagem || 'Falha ao criar equipe.';
                errEl.classList.remove('d-none');
            }
        } catch (error) {
            errEl.textContent = error.message;
            errEl.classList.remove('d-none');
        }
    });

    // Submissão: Atribuir Tarefa de Integração (RF06, RF07)
    const formTarefa = document.getElementById('form-atribuir-tarefa');
    formTarefa.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errEl = document.getElementById('modal-tarefa-error');
        errEl.classList.add('d-none');

        const isEquipe = radioEquipe.checked;
        const idFuncionario = isEquipe ? null : document.getElementById('tar-funcionario').value;
        const idEquipe = isEquipe ? document.getElementById('tar-equipe').value : null;

        if (!isEquipe && !idFuncionario) {
            errEl.textContent = 'Selecione o colaborador destinatário da tarefa.';
            errEl.classList.remove('d-none');
            return;
        }

        if (isEquipe && !idEquipe) {
            errEl.textContent = 'Selecione a equipe de trabalho.';
            errEl.classList.remove('d-none');
            return;
        }

        const dados = {
            titulo: document.getElementById('tar-titulo').value.trim(),
            descricao: document.getElementById('tar-descricao').value.trim(),
            prazo: document.getElementById('tar-prazo').value,
            id_funcionario: idFuncionario || null,
            id_equipe: idEquipe || null
        };

        try {
            const res = await window.JanoAPI.Tarefas.criar(dados);
            if (res.sucesso) {
                modalTarefa.hide();
                formTarefa.reset();
                window.JanoComponents.showToast('Tarefa de integração atribuída com sucesso!', 'sucesso');
                await carregarTarefas();
                await carregarMetricas();
            } else {
                errEl.textContent = res.mensagem || 'Erro ao atribuir tarefa.';
                errEl.classList.remove('d-none');
            }
        } catch (error) {
            errEl.textContent = error.message;
            errEl.classList.remove('d-none');
        }
    });

    // Submissão: Vincular Membro à Equipe (RF11, RN08)
    const formVincular = document.getElementById('form-vincular-membro');
    formVincular.addEventListener('submit', async (e) => {
        e.preventDefault();
        const idEquipe = document.getElementById('vincular-equipe-id').value;
        const idFuncionario = document.getElementById('vincular-funcionario-select').value;

        if (!idFuncionario) {
            alert('Selecione um colaborador para alocar.');
            return;
        }

        try {
            const res = await window.JanoAPI.Equipes.vincularMembro(idEquipe, idFuncionario);
            if (res.sucesso) {
                modalVincular.hide();
                window.JanoComponents.showToast('Colaborador alocado na equipe com sucesso!', 'sucesso');
                await carregarDadosCompletos();
                await carregarMetricas();
            } else {
                alert(res.mensagem || 'Falha ao alocar colaborador.');
            }
        } catch (error) {
            alert(error.message);
        }
    });
});

async function carregarMetricas() {
    try {
        const res = await window.JanoAPI.Dashboard.getMetricasGestor();
        if (res.sucesso && res.metricas) {
            const m = res.metricas;
            document.getElementById('metric-total-equipes').textContent = m.totalEquipes;
            document.getElementById('metric-total-membros').textContent = m.totalMembros;
            document.getElementById('metric-tarefas-pendentes').textContent = m.pendentes;
            document.getElementById('metric-taxa-sucesso').textContent = `${m.taxaSucesso}%`;
        }
    } catch (err) {
        console.error('Erro ao carregar métricas do gestor:', err);
    }
}

async function carregarDadosCompletos() {
    await carregarEquipes();
    await carregarFuncionariosSelect();
    await carregarTarefas();
}

async function carregarEquipes() {
    const container = document.getElementById('container-equipes');

    try {
        const res = await window.JanoAPI.Equipes.listar();
        if (!res.sucesso || !res.equipes) {
            container.innerHTML = '<div class="col-12 text-center text-danger">Falha ao carregar equipes.</div>';
            return;
        }

        equipesGlobais = res.equipes;

        if (equipesGlobais.length === 0) {
            container.innerHTML = `
                <div class="col-12">
                    <div class="card card-jano p-4 text-center text-muted">
                        <i class="bi bi-diagram-3 fs-1 text-primary mb-2"></i>
                        <h5>Nenhuma equipe cadastrada ainda</h5>
                        <p class="small mb-0">Clique no botão "Criar Equipe" acima para criar o primeiro time de trabalho.</p>
                    </div>
                </div>
            `;
            return;
        }

        // Renderiza select no modal de tarefa
        const selectEquipeTarefa = document.getElementById('tar-equipe');
        selectEquipeTarefa.innerHTML = '<option value="">Selecione uma equipe...</option>' + 
            equipesGlobais.map(eq => `<option value="${eq.id}">${eq.nome} (${eq.departamento})</option>`).join('');

        // Renderiza cards de equipes
        container.innerHTML = equipesGlobais.map(eq => {
            const membrosList = eq.membros && eq.membros.length > 0
                ? eq.membros.map(m => `
                    <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-3">
                        <div>
                            <div class="fw-semibold small">${m.nome}</div>
                            <small class="text-muted">${m.cargo}</small>
                        </div>
                        <button type="button" class="btn btn-outline-danger btn-sm p-1 px-2" title="Desvincular da equipe" onclick="removerMembroEquipe(${eq.id}, ${m.id}, '${escapeHtml(m.nome)}')">
                            <i class="bi bi-x-circle"></i>
                        </button>
                    </li>
                `).join('')
                : '<li class="list-group-item text-center py-3 text-muted small">Nenhum colaborador alocado nesta equipe.</li>';

            return `
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="card card-jano h-100">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center py-3 border-bottom">
                            <div>
                                <h6 class="fw-bold mb-0 text-primary">${eq.nome}</h6>
                                <small class="text-muted"><i class="bi bi-building me-1"></i>${eq.departamento}</small>
                            </div>
                            <span class="badge bg-primary rounded-pill">${eq.total_membros || 0} membros</span>
                        </div>
                        <div class="card-body p-0">
                            <div class="p-2 bg-light-subtle border-bottom d-flex justify-content-between align-items-center">
                                <small class="text-muted fw-semibold">Gestor: ${eq.gestor_nome || 'N/A'}</small>
                                <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2" onclick="abrirModalVincular(${eq.id}, '${escapeHtml(eq.nome)}')">
                                    <i class="bi bi-person-plus-fill me-1"></i>Alocar
                                </button>
                            </div>
                            <ul class="list-group list-group-flush" style="max-height: 220px; overflow-y: auto;">
                                ${membrosList}
                            </ul>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    } catch (err) {
        container.innerHTML = `<div class="col-12 text-center text-danger">Erro: ${err.message}</div>`;
    }
}

async function carregarFuncionariosSelect() {
    try {
        const res = await window.JanoAPI.Funcionarios.listar();
        if (res.sucesso && res.funcionarios) {
            funcionariosGlobais = res.funcionarios;

            const selectTar = document.getElementById('tar-funcionario');
            selectTar.innerHTML = '<option value="">Selecione um colaborador...</option>' +
                funcionariosGlobais.map(f => `<option value="${f.id}">${f.nome} - ${f.cargo}</option>`).join('');
        }
    } catch (err) {
        console.error('Erro ao carregar lista de funcionários:', err);
    }
}

async function carregarTarefas() {
    const tbody = document.getElementById('tabela-tarefas-body');
    const badgeTotal = document.getElementById('badge-total-tarefas');

    try {
        const res = await window.JanoAPI.Tarefas.listar();
        if (!res.sucesso || !res.tarefas) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-danger">Falha ao carregar tarefas.</td></tr>';
            return;
        }

        const tarefas = res.tarefas;
        badgeTotal.textContent = `${tarefas.length} tarefa${tarefas.length === 1 ? '' : 's'}`;

        if (tarefas.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">Nenhuma tarefa atribuída no momento.</td></tr>';
            return;
        }

        tbody.innerHTML = tarefas.map(t => {
            const isConcluida = t.status === 'Concluida';
            const statusBadge = isConcluida
                ? '<span class="badge badge-concluida"><i class="bi bi-check-circle-fill me-1"></i>Concluída</span>'
                : '<span class="badge badge-pendente"><i class="bi bi-clock-history me-1"></i>Pendente</span>';

            const destinatario = t.funcionario_nome
                ? `<span class="fw-semibold"><i class="bi bi-person me-1"></i>${t.funcionario_nome}</span>`
                : `<span class="badge bg-secondary"><i class="bi bi-people-fill me-1"></i>Equipe: ${t.equipe_nome || 'Todas'}</span>`;

            const formatPrazo = t.prazo ? t.prazo.split('T')[0] : 'S/ prazo';

            let evidenciaContent = '<span class="text-muted small">Aguardando entrega</span>';
            if (t.evidencia) {
                const isUrl = t.evidencia.startsWith('http://') || t.evidencia.startsWith('https://');
                evidenciaContent = isUrl
                    ? `<a href="${t.evidencia}" target="_blank" class="btn btn-sm btn-outline-success py-0 px-2 small"><i class="bi bi-box-arrow-up-right me-1"></i>Acessar Link</a>`
                    : `<span class="small text-secondary" title="${t.evidencia}"><i class="bi bi-chat-left-quote me-1"></i>${t.evidencia.length > 50 ? t.evidencia.substring(0, 50) + '...' : t.evidencia}</span>`;
            }

            return `
                <tr>
                    <td>
                        <div class="fw-bold text-dark">${t.titulo}</div>
                        <small class="text-muted">${t.descricao || 'Sem descrição adicional'}</small>
                    </td>
                    <td>${destinatario}</td>
                    <td>
                        <span class="small fw-semibold text-secondary"><i class="bi bi-calendar-event me-1"></i>${formatPrazo}</span>
                    </td>
                    <td>${statusBadge}</td>
                    <td>${evidenciaContent}</td>
                </tr>
            `;
        }).join('');
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-4 text-danger">Erro: ${err.message}</td></tr>`;
    }
}

window.abrirModalVincular = function(idEquipe, nomeEquipe) {
    document.getElementById('vincular-equipe-id').value = idEquipe;
    document.getElementById('vincular-equipe-nome').value = nomeEquipe;

    const selectFunc = document.getElementById('vincular-funcionario-select');
    selectFunc.innerHTML = '<option value="">Selecione o colaborador...</option>' +
        funcionariosGlobais.map(f => `<option value="${f.id}">${f.nome} (${f.cargo})</option>`).join('');

    const modal = bootstrap.Modal.getInstance(document.getElementById('modal-vincular-membro')) || 
                  new bootstrap.Modal(document.getElementById('modal-vincular-membro'));
    modal.show();
};

window.removerMembroEquipe = async function(idEquipe, idFuncionario, nomeFuncionario) {
    const confirmou = confirm(`Remover o colaborador "${nomeFuncionario}" desta equipe? (RF13)`);
    if (!confirmou) return;

    try {
        const res = await window.JanoAPI.Equipes.removerMembro(idEquipe, idFuncionario);
        if (res.sucesso) {
            window.JanoComponents.showToast(`Colaborador removido da equipe.`, 'info');
            await carregarDadosCompletos();
            await carregarMetricas();
        } else {
            alert(res.mensagem || 'Falha ao remover colaborador.');
        }
    } catch (error) {
        alert(error.message);
    }
};

function escapeHtml(text) {
    return (text || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
}
