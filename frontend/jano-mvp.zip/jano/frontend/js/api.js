/**
 * JANO Client API - Módulo Centralizado de Comunicação HTTP com o Back-end
 * Isolamento de requisições com Fetch API, tratamento de tokens e cabeçalhos.
 */

// Permite flexibilidade de deploy: Vercel + Render ou Monolítico
const API_BASE_URL = window.API_BASE_URL || (
    window.location.port === '3000' || !window.location.port
        ? '/api'
        : 'http://localhost:3000/api'
);

/**
 * Função genérica para requisições com tratamento de erro e injeção do JWT
 */
async function apiRequest(endpoint, { method = 'GET', body = null, headers = {} } = {}) {
    const token = localStorage.getItem('jano_token');

    const defaultHeaders = {
        'Content-Type': 'application/json',
        ...headers
    };

    if (token) {
        defaultHeaders['Authorization'] = `Bearer ${token}`;
    }

    const config = {
        method,
        headers: defaultHeaders
    };

    if (body) {
        config.body = JSON.stringify(body);
    }

    try {
        const url = `${API_BASE_URL}${endpoint}`;
        const response = await fetch(url, config);
        const data = await response.json();

        // Tratamento de Primeiro Acesso Obrigatório (RN03)
        if (response.status === 403 && data.codigo === 'PRIMEIRO_ACESSO_OBRIGATORIO') {
            if (!window.location.pathname.includes('alterar-senha.html')) {
                window.location.href = 'alterar-senha.html';
                return;
            }
        }

        // Tratamento de Token Expirado ou Sessão Inválida
        if (response.status === 401 && !endpoint.includes('/auth/login')) {
            localStorage.removeItem('jano_token');
            localStorage.removeItem('jano_user');
            window.location.href = 'login.html';
            return;
        }

        if (!response.ok) {
            throw new Error(data.mensagem || `Erro na requisição: ${response.status}`);
        }

        return data;
    } catch (error) {
        console.error(`[API Request Error] ${method} ${endpoint}:`, error);
        throw error;
    }
}

// -------------------------------------------------------------
// Módulos Especializados da API
// -------------------------------------------------------------

const AuthAPI = {
    login: (email, senha) => apiRequest('/auth/login', { method: 'POST', body: { email, senha } }),
    alterarSenha: (senhaAtual, novaSenha, confirmacaoSenha) => 
        apiRequest('/auth/alterar-senha', { method: 'POST', body: { senhaAtual, novaSenha, confirmacaoSenha } }),
    getUsuarioAtual: () => apiRequest('/auth/me')
};

const FuncionariosAPI = {
    listar: () => apiRequest('/funcionarios'),
    obterPorId: (id) => apiRequest(`/funcionarios/${id}`),
    cadastrar: (dados) => apiRequest('/funcionarios', { method: 'POST', body: dados }),
    excluir: (id) => apiRequest(`/funcionarios/${id}`, { method: 'DELETE' })
};

const EquipesAPI = {
    listar: (somenteMinhas = false) => apiRequest(`/equipes?somenteMinhas=${somenteMinhas}`),
    criar: (dados) => apiRequest('/equipes', { method: 'POST', body: dados }),
    vincularMembro: (idEquipe, idFuncionario) => 
        apiRequest(`/equipes/${idEquipe}/membros`, { method: 'POST', body: { id_funcionario: idFuncionario } }),
    removerMembro: (idEquipe, idFuncionario) => 
        apiRequest(`/equipes/${idEquipe}/membros/${idFuncionario}`, { method: 'DELETE' }),
    listarMembros: (idEquipe) => apiRequest(`/equipes/${idEquipe}/membros`)
};

const TarefasAPI = {
    listar: (filtros = {}) => {
        const queryParams = new URLSearchParams(filtros).toString();
        return apiRequest(`/tarefas${queryParams ? `?${queryParams}` : ''}`);
    },
    criar: (dados) => apiRequest('/tarefas', { method: 'POST', body: dados }),
    concluir: (id, evidencia) => apiRequest(`/tarefas/${id}/concluir`, { method: 'PATCH', body: { evidencia } })
};

const DashboardAPI = {
    getMetricasRH: () => apiRequest('/dashboard/metricas-rh'),
    getMetricasGestor: () => apiRequest('/dashboard/metricas-gestor')
};

window.JanoAPI = {
    Auth: AuthAPI,
    Funcionarios: FuncionariosAPI,
    Equipes: EquipesAPI,
    Tarefas: TarefasAPI,
    Dashboard: DashboardAPI
};
