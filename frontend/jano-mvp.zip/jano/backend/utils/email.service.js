const nodemailer = require('nodemailer');

/**
 * Serviço de Envio de E-mails do JANO
 * Suporta envio real via Gmail / SMTP (com Senha de App do Google)
 * ou Fallback simulado caso as credenciais não estejam configuradas.
 */

function criarTransportador() {
    const user = process.env.EMAIL_USER || process.env.GMAIL_USER || process.env.SMTP_USER;
    const pass = process.env.EMAIL_PASS || process.env.GMAIL_APP_PASSWORD || process.env.SMTP_PASS;

    if (!user || !pass) {
        return null;
    }

    return nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user,
            pass
        }
    });
}

async function sendTemporaryCredentialsEmail({ nome, email, senhaTemporaria, cargo }) {
    const timestamp = new Date().toISOString();
    const transporter = criarTransportador();

    const senderEmail = process.env.EMAIL_USER || process.env.GMAIL_USER || 'no-reply@jano-onboarding.corp';
    const assunto = 'Bem-vindo ao JANO! Suas credenciais de acesso corporativo';

    const corpoTexto = `
Olá, ${nome}!

Seu cadastro como "${cargo}" foi realizado com sucesso no sistema JANO de Onboarding Corporativo.

Para acessar o portal e iniciar sua integração, utilize as credenciais temporárias abaixo:
  • Portal: ${process.env.APP_FRONTEND_URL || 'http://localhost:3000/login.html'}
  • E-mail: ${email}
  • Senha Temporária: ${senhaTemporaria}

IMPORTANTE:
No seu primeiro acesso, o sistema exigirá obrigatoriamente a troca desta senha temporária por uma nova senha definitiva e pessoal.

Atenciosamente,
Equipe de Recursos Humanos & Gente e Gestão - JANO
    `.trim();

    const corpoHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 8px; background-color: #f8fafc;">
        <div style="background: linear-gradient(135deg, #1e3a8a, #0d6efd); padding: 20px; border-radius: 6px; text-align: center; color: white;">
            <h2 style="margin: 0; font-size: 24px;">⚡ SISTEMA JANO</h2>
            <p style="margin: 5px 0 0 0; font-size: 13px; opacity: 0.9;">Onboarding Corporativo</p>
        </div>
        <div style="padding: 24px 8px; color: #1e293b; line-height: 1.6;">
            <p style="font-size: 16px;">Olá, <strong>${nome}</strong>!</p>
            <p>Seu cadastro como <strong>${cargo}</strong> foi realizado com sucesso em nosso sistema de integração corporativa.</p>
            <p>Utilize as credenciais temporárias abaixo para realizar seu primeiro acesso:</p>
            
            <div style="background-color: #ffffff; border: 1px dashed #cbd5e1; border-radius: 6px; padding: 16px; margin: 20px 0;">
                <p style="margin: 0 0 8px 0;"><strong>Login (E-mail):</strong> <span style="color: #0d6efd;">${email}</span></p>
                <p style="margin: 0;"><strong>Senha Temporária:</strong> <code style="font-size: 16px; font-weight: bold; background: #e0f2fe; padding: 4px 8px; border-radius: 4px; color: #0369a1;">${senhaTemporaria}</code></p>
            </div>

            <div style="background-color: #fffbeb; border-left: 4px solid #f59e0b; padding: 12px; margin: 20px 0; font-size: 14px; color: #92400e;">
                <strong>Atenção:</strong> Por motivos de segurança, você será solicitado(a) a criar uma nova senha definitiva no primeiro acesso.
            </div>

            <div style="text-align: center; margin-top: 28px;">
                <a href="${process.env.APP_FRONTEND_URL || 'http://localhost:3000/login.html'}" style="background-color: #0d6efd; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">Acessar Portal JANO</a>
            </div>
        </div>
        <div style="border-top: 1px solid #e2e8f0; padding-top: 16px; font-size: 12px; color: #64748b; text-align: center;">
            Este é um e-mail automático gerado pelo Sistema JANO de Onboarding Corporativo.
        </div>
    </div>
    `;

    // Se as credenciais do Gmail/SMTP estiverem configuradas, envia o e-mail real!
    if (transporter) {
        try {
            const info = await transporter.sendMail({
                from: `"JANO Onboarding" <${senderEmail}>`,
                to: email,
                subject: assunto,
                text: corpoTexto,
                html: corpoHtml
            });

            console.log(`📧 [E-mail Real Enviado via Gmail]: ID ${info.messageId} para ${email}`);
            return {
                success: true,
                modo: 'real',
                messageId: info.messageId,
                deliveredTo: email,
                sentAt: timestamp
            };
        } catch (err) {
            console.error('⚠️ Falha no envio via Gmail/SMTP. Alternando para modo simulado:', err.message);
        }
    }

    // Modo simulado (fallback quando não há SMTP configurado no .env)
    console.log(`
======================================================================
[DISPARO DE E-MAIL - SISTEMA JANO ONBOARDING] (Modo Simulado / Fallback)
De: ${senderEmail}
Para: ${nome} <${email}>
Assunto: ${assunto}
Data: ${timestamp}
----------------------------------------------------------------------
${corpoTexto}
======================================================================
    `);

    return {
        success: true,
        modo: 'simulado',
        deliveredTo: email,
        sentAt: timestamp
    };
}

module.exports = {
    sendTemporaryCredentialsEmail
};
