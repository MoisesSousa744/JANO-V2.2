const db = require('../config/database');

/**
 * Controller de Tarefas de Integração (Onboarding)
 * Regras: RF06, RF07, RF08, RF09, RN04, RN05
 */

async function criarTarefa(req, res, next) {
    try {
        const { titulo, descricao, prazo, id_funcionario, id_equipe } = req.body;

        if (!titulo || !prazo) {
            return res.status(400).json({
                sucesso: false,
                mensagem: 'Título e Prazo da tarefa são obrigatórios.'
            });
        }

        if (!id_funcionario && !id_equipe) {
            return res.status(400).json({
                sucesso: false,
                mensagem: 'A tarefa deve ser atribuída a um Colaborador específico ou a uma Equipe.'
            });
        }

        const criadorId = req.usuario.id;
        const funcionarioId = id_funcionario ? Number(id_funcionario) : null;
        const equipeId = id_equipe ? Number(id_equipe) : null;

        const [resultado] = await db.query(
            `INSERT INTO tarefas (titulo, descricao, prazo, status, id_funcionario, id_equipe, id_criador, data_criacao)
             VALUES (?, ?, ?, 'Pendente', ?, ?, ?, NOW())`,
            [titulo.trim(), descricao ? descricao.trim() : null, prazo, funcionarioId, equipeId, criadorId]
        );

        res.status(201).json({
            sucesso: true,
            mensagem: 'Tarefa de integração criada e atribuída com sucesso!',
            tarefa: {
                id: resultado.insertId,
                titulo,
                descricao,
                prazo,
                status: 'Pendente',
                id_funcionario: funcionarioId,
                id_equipe: equipeId,
                id_criador: criadorId
            }
        });
    } catch (error) {
        next(error);
    }
}

async function listarTarefas(req, res, next) {
    try {
        const usuario = req.usuario;

        // Se for perfil Funcionário, aplica estritamente a Regra RN04:
        // visualiza somente as tarefas atribuídas diretamente a ele ou à sua equipe
        if (usuario.perfil === 'Funcionario') {
            const [tarefas] = await db.query(
                `SELECT t.id, t.titulo, t.descricao, t.prazo, t.status, t.evidencia, t.data_conclusao,
                        t.id_funcionario, t.id_equipe, t.id_criador, t.data_criacao,
                        e.nome as equipe_nome, f_criador.nome as criador_nome
                 FROM tarefas t
                 LEFT JOIN equipes e ON t.id_equipe = e.id
                 LEFT JOIN funcionarios f_criador ON t.id_criador = f_criador.id
                 WHERE t.id_funcionario = ? 
                    OR t.id_equipe IN (
                        SELECT id_equipe FROM funcionario_equipe WHERE id_funcionario = ?
                    )
                 ORDER BY t.status DESC, t.prazo ASC`,
                [usuario.id, usuario.id]
            );

            const pendentes = tarefas.filter(t => t.status === 'Pendente');
            const concluidas = tarefas.filter(t => t.status === 'Concluida');

            return res.status(200).json({
                sucesso: true,
                total: tarefas.length,
                totalPendentes: pendentes.length,
                totalConcluidas: concluidas.length,
                pendentes,
                concluidas,
                todas: tarefas
            });
        }

        // Se for Gestor ou RH, lista todas com nomes dos colaboradores e equipes
        let querySql = `
            SELECT t.id, t.titulo, t.descricao, t.prazo, t.status, t.evidencia, t.data_conclusao,
                   t.id_funcionario, t.id_equipe, t.id_criador, t.data_criacao,
                   f.nome as funcionario_nome, f.cargo as funcionario_cargo,
                   e.nome as equipe_nome,
                   fc.nome as criador_nome
            FROM tarefas t
            LEFT JOIN funcionarios f ON t.id_funcionario = f.id
            LEFT JOIN equipes e ON t.id_equipe = e.id
            LEFT JOIN funcionarios fc ON t.id_criador = fc.id
        `;
        let params = [];

        if (req.query.id_equipe) {
            querySql += ' WHERE t.id_equipe = ?';
            params.push(Number(req.query.id_equipe));
        } else if (req.query.id_funcionario) {
            querySql += ' WHERE t.id_funcionario = ?';
            params.push(Number(req.query.id_funcionario));
        }

        querySql += ' ORDER BY t.id DESC';

        const [tarefas] = await db.query(querySql, params);

        res.status(200).json({
            sucesso: true,
            total: tarefas.length,
            tarefas
        });
    } catch (error) {
        next(error);
    }
}

async function concluirTarefa(req, res, next) {
    try {
        const id = Number(req.params.id);
        const { evidencia } = req.body;

        if (!evidencia || !evidencia.trim()) {
            return res.status(400).json({
                sucesso: false,
                mensagem: 'Forneça uma descrição ou link de comprovação como evidência da entrega.'
            });
        }

        // Busca a tarefa
        const [rows] = await db.query('SELECT * FROM tarefas WHERE id = ?', [id]);
        if (!rows.length) {
            return res.status(404).json({
                sucesso: false,
                mensagem: 'Tarefa de integração não encontrada.'
            });
        }

        const tarefa = rows[0];

        // Se for funcionário, valida permissão sobre a tarefa (RN04)
        if (req.usuario.perfil === 'Funcionario') {
            const isDono = tarefa.id_funcionario === req.usuario.id;
            
            // Verifica se a tarefa é da equipe do funcionário
            let isMembroEquipe = false;
            if (tarefa.id_equipe) {
                const [vinculo] = await db.query(
                    'SELECT id FROM funcionario_equipe WHERE id_funcionario = ? AND id_equipe = ?',
                    [req.usuario.id, tarefa.id_equipe]
                );
                isMembroEquipe = vinculo && vinculo.length > 0;
            }

            if (!isDono && !isMembroEquipe) {
                return res.status(403).json({
                    sucesso: false,
                    mensagem: 'Você só pode concluir tarefas atribuídas diretamente a você ou à sua equipe.'
                });
            }
        }

        const dataConclusao = new Date();
        await db.query(
            `UPDATE tarefas SET status = 'Concluida', evidencia = ?, data_conclusao = ? WHERE id = ?`,
            [evidencia.trim(), dataConclusao, id]
        );

        res.status(200).json({
            sucesso: true,
            mensagem: 'Tarefa concluída e evidência registrada com sucesso!',
            tarefa: {
                id,
                status: 'Concluida',
                evidencia: evidencia.trim(),
                data_conclusao: dataConclusao
            }
        });
    } catch (error) {
        next(error);
    }
}

module.exports = {
    criarTarefa,
    listarTarefas,
    concluirTarefa
};
