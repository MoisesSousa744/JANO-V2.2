const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { generateTemporaryPassword } = require('../utils/password.generator');
const { sendTemporaryCredentialsEmail } = require('../utils/email.service');

/**
 * Controller de Gestão de Funcionários (RH)
 * Regras: RF01, RF02, RF03, RF15, RN01, RN02, RN07, RN08
 */

async function cadastrarFuncionario(req, res, next) {
    try {
        const { nome, cpf, cargo, telefone, email, perfil = 'Funcionario', id_equipe } = req.body;

        if (!nome || !cpf || !cargo || !email) {
            return res.status(400).json({
                sucesso: false,
                mensagem: 'Nome, CPF, Cargo e E-mail são campos obrigatórios.'
            });
        }

        const perfisValidos = ['RH', 'Gestor', 'Funcionario'];
        if (!perfisValidos.includes(perfil)) {
            return res.status(400).json({
                sucesso: false,
                mensagem: `Perfil inválido. Valores aceitos: ${perfisValidos.join(', ')}.`
            });
        }

        // Verifica se e-mail ou CPF já existem
        const [existentes] = await db.query(
            'SELECT id, email, cpf FROM funcionarios WHERE email = ?',
            [email.trim().toLowerCase()]
        );

        if (existentes && existentes.length > 0) {
            return res.status(409).json({
                sucesso: false,
                mensagem: 'Já existe um funcionário cadastrado com este e-mail.'
            });
        }

        // RF02: Gera senha temporária aleatória
        const senhaTemporaria = generateTemporaryPassword(10);
        const senhaHash = await bcrypt.hash(senhaTemporaria, 10);

        // Insere o funcionário com primeiro_acesso = TRUE
        const equipeId = id_equipe ? Number(id_equipe) : null;
        const [resultado] = await db.query(
            `INSERT INTO funcionarios (nome, cpf, cargo, telefone, email, senha_hash, primeiro_acesso, perfil, id_equipe, data_criacao)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
            [nome.trim(), cpf.trim(), cargo.trim(), telefone ? telefone.trim() : null, email.trim().toLowerCase(), senhaHash, 1, perfil, equipeId]
        );

        const novoId = resultado.insertId;

        // Se houver equipe selecionada, vincula também na tabela associativa N:N (RN08)
        if (equipeId) {
            await db.query(
                `INSERT INTO funcionario_equipe (id_funcionario, id_equipe, data_vinculo) VALUES (?, ?, NOW())`,
                [novoId, equipeId]
            );
        }

        // RF03: Simula o disparo de e-mail com as credenciais
        await sendTemporaryCredentialsEmail({
            nome,
            email,
            senhaTemporaria,
            cargo
        });

        return res.status(201).json({
            sucesso: true,
            mensagem: 'Funcionário cadastrado com sucesso! Credenciais temporárias geradas e enviadas por e-mail.',
            funcionario: {
                id: novoId,
                nome,
                cpf,
                cargo,
                telefone,
                email,
                perfil,
                id_equipe: equipeId,
                primeiro_acesso: true
            },
            credenciaisTemporarias: {
                email,
                senhaTemporaria
            }
        });
    } catch (error) {
        next(error);
    }
}

async function listarFuncionarios(req, res, next) {
    try {
        const [funcionarios] = await db.query(
            `SELECT f.id, f.nome, f.cpf, f.cargo, f.telefone, f.email, f.primeiro_acesso, f.perfil, f.id_equipe, f.data_criacao
             FROM funcionarios f
             ORDER BY f.id DESC`
        );

        // Adiciona informações de equipes associadas e progresso
        const [equipes] = await db.query('SELECT * FROM equipes');
        const [todasTarefas] = await db.query('SELECT * FROM tarefas');

        const funcionariosFormatados = funcionarios.map(func => {
            const equipe = equipes.find(e => e.id === func.id_equipe);
            const tarefasDoFunc = todasTarefas.filter(t => t.id_funcionario === func.id);
            const concluidas = tarefasDoFunc.filter(t => t.status === 'Concluida').length;
            const total = tarefasDoFunc.length;
            const progresso = total > 0 ? Math.round((concluidas / total) * 100) : 0;

            return {
                ...func,
                primeiro_acesso: Boolean(func.primeiro_acesso),
                equipe_nome: equipe ? equipe.nome : 'Sem Equipe',
                total_tarefas: total,
                tarefas_concluidas: concluidas,
                progresso_onboarding: progresso
            };
        });

        res.status(200).json({
            sucesso: true,
            total: funcionariosFormatados.length,
            funcionarios: funcionariosFormatados
        });
    } catch (error) {
        next(error);
    }
}

async function obterFuncionarioPorId(req, res, next) {
    try {
        const id = Number(req.params.id);
        const [rows] = await db.query(
            'SELECT id, nome, cpf, cargo, telefone, email, primeiro_acesso, perfil, id_equipe, data_criacao FROM funcionarios WHERE id = ?',
            [id]
        );

        if (!rows.length) {
            return res.status(404).json({
                sucesso: false,
                mensagem: 'Funcionário não encontrado.'
            });
        }

        const funcionario = rows[0];
        const [equipesAssociadas] = await db.query(
            `SELECT e.id, e.nome, e.departamento, fe.data_vinculo
             FROM funcionario_equipe fe
             JOIN equipes e ON fe.id_equipe = e.id
             WHERE fe.id_funcionario = ?`,
            [id]
        );

        res.status(200).json({
            sucesso: true,
            funcionario: {
                ...funcionario,
                primeiro_acesso: Boolean(funcionario.primeiro_acesso),
                equipes: equipesAssociadas
            }
        });
    } catch (error) {
        next(error);
    }
}

/**
 * RF15 / RN01 / RN07: Exclusão de funcionário em caso de desligamento
 */
async function excluirFuncionario(req, res, next) {
    try {
        const id = Number(req.params.id);

        if (id === req.usuario.id) {
            return res.status(400).json({
                sucesso: false,
                mensagem: 'Você não pode excluir o seu próprio usuário de administrador.'
            });
        }

        const [rows] = await db.query('SELECT id, nome FROM funcionarios WHERE id = ?', [id]);
        if (!rows.length) {
            return res.status(404).json({
                sucesso: false,
                mensagem: 'Funcionário não encontrado para exclusão.'
            });
        }

        await db.query('DELETE FROM funcionarios WHERE id = ?', [id]);

        res.status(200).json({
            sucesso: true,
            mensagem: `Desligamento efetuado: Funcionário "${rows[0].nome}" (ID ${id}) foi excluído do sistema com sucesso.`
        });
    } catch (error) {
        next(error);
    }
}

module.exports = {
    cadastrarFuncionario,
    listarFuncionarios,
    obterFuncionarioPorId,
    excluirFuncionario
};
